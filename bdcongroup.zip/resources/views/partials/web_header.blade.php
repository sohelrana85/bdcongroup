<header class="top-header">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7">
                <div class="header-left">
                    <div class="header-left-card">
                        <ul>
                            <li>
                                <div class="head-icon">
                                    <i class='bx bxs-envelope'></i>
                                </div>
                                <a href="mailto:{{ $content->email }}">
                                    <span class="__cf_email__"
                                        data-cfemail="224b4c444d62444b4c47410c414d4f">{{ $content->email }}</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="header-right">
                    <div class="top-social-link">
                        <ul>
                            <li>
                                <a href="{{ $content->facebook }}" target="_blank">
                                    <i class='bx bxl-facebook'></i>
                                </a>
                            </li>
                            <li>
                                <a href="{{ $content->twitter }}" target="_blank">
                                    <i class='bx bxl-twitter'></i>
                                </a>
                            </li>
                            <li>
                                <a href="{{ $content->instagram }}" target="_blank">
                                    <i class='bx bxl-instagram'></i>
                                </a>
                            </li>
                            <li>
                                <a href="{{ $content->youtube }}" target="_blank">
                                    <i class='bx bxl-youtube'></i>
                                </a>
                            </li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </div>
</header>

<div class="navbar-area">
    <div class="mobile-nav">
        <a href="{{ route('index') }}" class="logo">
            <img src="{{ asset($content->logo) }}" class="logo-one" alt="Logo">
        </a>
        <h4>{{ $content->com_name }}</h4>
    </div>

    <div class="main-nav">
        <div class="container">
            <nav class="navbar navbar-expand-md navbar-light ">
                <a class="navbar-brand" href="{{ route('index') }}">
                    <img src="{{ asset($content->logo) }}" class="logo-one" alt="Logo">
                    <img src="{{ asset($content->logo) }}" class="logo-two" alt="Logo">
                </a>
                <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a href="{{ route('index') }}" class="nav-link {{ Route::is('index') ? 'active' : '' }}">
                                Home
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="javascript:" class="nav-link">
                                About
                            </a>
                        </li>
                        {{-- <li class="nav-item">
                            <a href="{{ route('about') }}" class="nav-link {{ Route::is('about') ? 'active' : '' }}">
                                About
                            </a>
                        </li> --}}

                        <li class="nav-item dropdown">
                            <a class="nav-link" href="#" id="navbarDropdown" role="button" aria-haspopup="true"
                                aria-expanded="false">
                                Our Project
                                <i class='bx bx-chevron-down'></i>
                            </a>

                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li class="nav-item dropdown">
                                    <a class="dropdown-item" href="#" id="navbarDropdown1" role="button"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Project 1
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <a class="dropdown-item" href="#" id="navbarDropdown1" role="button"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Project 2
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <a class="dropdown-item" href="#" id="navbarDropdown1" role="button"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Project 3
                                        <i class='bx bx-chevron-down'></i>
                                    </a>

                                    {{-- @php
                                        $import_category = App\Models\Product::with('category')
                                            ->select('category_id')
                                            ->where('type', 'import')
                                            ->groupBy('category_id')
                                            ->get();
                                        $export_category = App\Models\Product::with('category')
                                            ->select('category_id')
                                            ->where('type', 'export')
                                            ->groupBy('category_id')
                                            ->get();
                                    @endphp

                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        @foreach ($export_category as $item)
                                            <li class="nav-item dropdown">
                                                <a class="dropdown-item"
                                                    href="{{ route('export.product.category', $item->category_id) }}"
                                                    id="navbarDropdown2" role="button" data-toggle="dropdown"
                                                    aria-haspopup="true" aria-expanded="false">
                                                    {{ $item->category->name }}
                                                    @if ($item->category->children->count() > 0)
                                                        <i class='bx bx-chevron-down'></i>
                                                    @endif

                                                </a>

                                                @if ($item->category->children->count() > 0)
                                                    <ul class="dropdown-menu dropdown_left"
                                                        aria-labelledby="navbarDropdown2">
                                                        @foreach ($item->category->children as $child)
                                                            <li><a class="dropdown-item"
                                                                    href="{{ route('export.product.category', $item->category_id) }}">{{ $child->name }}</a>
                                                            </li>
                                                        @endforeach
                                                    </ul>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ul> --}}

                                </li>

                                {{-- <li>
                                    <a class="dropdown-item" href="#" id="navbarDropdown1" role="button"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Import
                                        <i class='bx bx-chevron-down'></i>
                                    </a>

                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        @foreach ($import_category as $item)
                                            <li class="nav-item dropdown">
                                                <a class="dropdown-item"
                                                    href="{{ route('import.product.category', $item->category_id) }}"
                                                    id="navbarDropdown2" role="button" data-toggle="dropdown"
                                                    aria-haspopup="true" aria-expanded="false">
                                                    {{ $item->category->name }}
                                                    @if ($item->category->children->count() > 0)
                                                        <i class='bx bx-chevron-down'></i>
                                                    @endif
                                                </a>
                                                @if ($item->category->children->count() > 0)
                                                    <ul class="dropdown-menu dropdown_left"
                                                        aria-labelledby="navbarDropdown2">
                                                        @foreach ($item->category->children as $child)
                                                            <li><a class="dropdown-item"
                                                                    href="{{ route('import.product.category', $item->category_id) }}">{{ $child->name }}</a>
                                                            </li>
                                                        @endforeach
                                                    </ul>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ul>
                                </li> --}}

                                {{-- <li>
                                    <a class="dropdown-item" href="#" id="navbarDropdown1" role="button"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Suplier
                                        <i class='bx bx-chevron-down'></i>
                                    </a>

                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <li class="nav-item dropdown">
                                            <a class="" href="{{ route('product.suplier') }}">
                                                All Kinds of Goods
                                            </a>
                                        </li>
                                    </ul>
                                </li> --}}
                            </ul>
                        </li>

                        <li class="nav-item">
                            <a href="javascript:" class="nav-link">
                                Service
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="javascript:" class="nav-link">
                                News & Event
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="javascript:" class="nav-link">
                                Contact
                            </a>
                        </li>

                        {{-- <li class="nav-item">
                            <a href="{{ route('management') }}"
                                class="nav-link {{ Route::is('management') ? 'active' : '' }}">
                                Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('gallery.page') }}"
                                class="nav-link {{ Route::is('gallery.page') ? 'active' : '' }}">
                                Gallery
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('contact') }}"
                                class="nav-link {{ Route::is('contact') ? 'active' : '' }}">
                                Contact
                            </a>
                        </li> --}}
                    </ul>
                    <!-- <div class="others-options d-flex align-items-center">
                        <div class="option-item">
                            <i class='search-btn bx bx-search'></i>
                            <i class='close-btn bx bx-x'></i>
                            <div class="search-overlay search-popup">
                                <div class='search-box'>
                                    <form class="search-form">
                                        <input class="search-input" name="search" placeholder="Search" type="text">
                                        <button class="search-button" type="submit">
                                            <i class="bx bx-search"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                    </div> -->
                </div>
            </nav>
        </div>
    </div>
    <div class="side-nav-responsive">
        <div class="container">

            <div class="container">
                <div class="side-nav-inner">
                    <div class="side-nav justify-content-center align-items-center">
                        <div class="side-item">
                            <div class="option-item">
                                <div class="menu-icon d-in-line">
                                    <a href="#" class="burger-menu menu-icon-two">
                                        <i class='flaticon-menu'></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="side-item">
                            <div class="option-item">
                                <i class='search-btn bx bx-search'></i>
                                <i class='close-btn bx bx-x'></i>
                                <div class="search-overlay search-popup">
                                    <div class='search-box'>
                                        <form class="search-form">
                                            <input class="search-input" name="search" placeholder="Search"
                                                type="text">
                                            <button class="search-button" type="submit">
                                                <i class="bx bx-search"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('web_script')
    <script>
        (function($) {
            var defaults = {
                sm: 540,
                md: 720,
                lg: 960,
                xl: 1140,
                navbar_expand: 'lg'
            };
            $.fn.bootnavbar = function() {

                var screen_width = $(document).width();

                if (screen_width >= defaults.lg) {
                    $(this).find('.dropdown').hover(function() {
                        $(this).addClass('show');
                        $(this).find('.dropdown-menu').first().addClass('show').addClass('animated fadeIn')
                            .one('animationend oAnimationEnd mozAnimationEnd webkitAnimationEnd',
                                function() {
                                    $(this).removeClass('animated fadeIn');
                                });
                    }, function() {
                        $(this).removeClass('show');
                        $(this).find('.dropdown-menu').first().removeClass('show');
                    });
                }

                $('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
                    if (!$(this).next().hasClass('show')) {
                        $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
                    }
                    var $subMenu = $(this).next(".dropdown-menu");
                    $subMenu.toggleClass('show');

                    $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
                        $('.dropdown-submenu .show').removeClass("show");
                    });

                    return false;
                });
            };
        })(jQuery);
    </script>
@endpush
