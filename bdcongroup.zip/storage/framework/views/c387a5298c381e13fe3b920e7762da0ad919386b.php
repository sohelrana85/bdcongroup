
<?php $__env->startSection('title', 'Management Page'); ?>
<?php $__env->startSection('main_content'); ?>

    <div class="inner-banner inner-bg8">
        <div class="container">
            <div class="inner-title text-center">
                <h3>Management</h3>
                <ul>
                    <li>
                        <a href="<?php echo e(route('index')); ?>">Home</a>
                    </li>
                    <li>
                        <i class='bx bxs-chevron-right'></i>
                    </li>
                    <li>Management</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="team-area pt-4 pb-4">
        <div class="container">
            <div class="section-title text-center">
                <span>Our Management</span>
                <h2>Our Best Management</h2>
            </div>
            <div class="row border-bottom pt-4 pb-4">
                <?php $__currentLoopData = $management; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                <div class="col-lg-3 col-md-6">
                    <div class="team-card team_card">
                        <div class="team-img">
                            <img src="<?php echo e(asset($item->image)); ?>" alt="Images">
                            
                        </div>
                        <div class="content">
                            <h3><?php echo e($item->name); ?></h3>
                            <span><?php echo e($item->designation); ?></span><br>
                            <span><?php echo e($item->phone); ?></span>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bdcongroup\resources\views/pages/management.blade.php ENDPATH**/ ?>