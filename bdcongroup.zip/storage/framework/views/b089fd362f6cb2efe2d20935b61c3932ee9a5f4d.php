
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('main_content'); ?>

    <?php echo $__env->make('partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    

    <!-- Our Product section -->
    <div class="project-area pt-4 pb-4">
        <div class="container">
            <div class="project-title-two">
                <div class="section-title">
                    <h2>Our Projects</h2>
                </div>
            </div>
            <div class="tab project-tab text-center">

                <div class="tab_content pt-2">
                    <div class="tabs_item">
                        <div class="project-tab-item">
                            <div class="row">
                                <?php $__currentLoopData = $home_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-3 col-md-6">
                                        <div class="project-card">
                                            <a href=""> <img src="<?php echo e(asset($item->image)); ?>" alt="Images">
                                            </a>
                                            <div class="project-content project-content-bg">
                                                <h3><a href=""><?php echo e($item->name); ?></a>
                                                </h3>
                                                <div class="content">
                                                    
                                                    <a href="" class="project-more"> View Details
                                                    </a>
                                                </div>
                                                <div class="project-card-bottom"></div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="project-view-btn text-center">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Our Product section -->
    <div class="project-area pt-4 pb-4">
        <div class="container">
            <div class="project-title-two">
                <div class="section-title">
                    <h2>Our Services</h2>
                </div>
            </div>
            <div class="tab project-tab text-center">

                <div class="tab_content pt-2">
                    <div class="tabs_item">
                        <div class="project-tab-item">
                            <div class="row">
                                <?php $__currentLoopData = $home_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-3 col-md-6">
                                        <div class="project-card">
                                            <a href="">
                                                <img src="<?php echo e(asset($item->image)); ?>" alt="Images">
                                            </a>
                                            <div class="project-content project-content-bg">
                                                <h3><a href=""><?php echo e($item->name); ?></a>
                                                    
                                                </h3>
                                                <div class="content">
                                                    
                                                    <a href="" class="project-more"> View Details
                                                        <i class='flaticon-double-right-arrows-angles'></i>
                                                    </a>
                                                </div>
                                                <div class="project-card-bottom"></div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="project-view-btn text-center">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Our Brand section -->
    

    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bdcongroup\resources\views/pages/web_index.blade.php ENDPATH**/ ?>