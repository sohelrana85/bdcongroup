<header class="top-header">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7">
                <div class="header-left">
                    <div class="header-left-card">
                        <ul>
                            <li>
                                <div class="head-icon">
                                    <i class='bx bxs-envelope'></i>
                                </div>
                                <a href="mailto:<?php echo e($content->email); ?>">
                                    <span class="__cf_email__"
                                        data-cfemail="224b4c444d62444b4c47410c414d4f"><?php echo e($content->email); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="header-right">
                    <div class="top-social-link">
                        <ul>
                            <li>
                                <a href="<?php echo e($content->facebook); ?>" target="_blank">
                                    <i class='bx bxl-facebook'></i>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e($content->twitter); ?>" target="_blank">
                                    <i class='bx bxl-twitter'></i>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e($content->instagram); ?>" target="_blank">
                                    <i class='bx bxl-instagram'></i>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e($content->youtube); ?>" target="_blank">
                                    <i class='bx bxl-youtube'></i>
                                </a>
                            </li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </div>
</header>

<div class="navbar-area">
    <div class="mobile-nav">
        <a href="<?php echo e(route('index')); ?>" class="logo">
            <img src="<?php echo e(asset($content->logo)); ?>" class="logo-one" alt="Logo">
        </a>
        <h4><?php echo e($content->com_name); ?></h4>
    </div>

    <div class="main-nav">
        <div class="container">
            <nav class="navbar navbar-expand-md navbar-light ">
                <a class="navbar-brand" href="<?php echo e(route('index')); ?>">
                    <img src="<?php echo e(asset($content->logo)); ?>" class="logo-one" alt="Logo">
                    <img src="<?php echo e(asset($content->logo)); ?>" class="logo-two" alt="Logo">
                </a>
                <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a href="<?php echo e(route('index')); ?>" class="nav-link <?php echo e(Route::is('index') ? 'active' : ''); ?>">
                                Home
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="javascript:" class="nav-link">
                                About
                            </a>
                        </li>
                        

                        <li class="nav-item dropdown">
                            <a class="nav-link" href="#" id="navbarDropdown" role="button" aria-haspopup="true"
                                aria-expanded="false">
                                Our Project
                                <i class='bx bx-chevron-down'></i>
                            </a>

                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li class="nav-item dropdown">
                                    <a class="dropdown-item" href="#" id="navbarDropdown1" role="button"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Project 1
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <a class="dropdown-item" href="#" id="navbarDropdown1" role="button"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Project 2
                                        <i class='bx bx-chevron-down'></i>
                                    </a>
                                    <a class="dropdown-item" href="#" id="navbarDropdown1" role="button"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Project 3
                                        <i class='bx bx-chevron-down'></i>
                                    </a>

                                    

                                </li>

                                

                                
                            </ul>
                        </li>

                        <li class="nav-item">
                            <a href="javascript:" class="nav-link">
                                Service
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="javascript:" class="nav-link">
                                News & Event
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="javascript:" class="nav-link">
                                Contact
                            </a>
                        </li>

                        
                    </ul>
                    <!-- <div class="others-options d-flex align-items-center">
                        <div class="option-item">
                            <i class='search-btn bx bx-search'></i>
                            <i class='close-btn bx bx-x'></i>
                            <div class="search-overlay search-popup">
                                <div class='search-box'>
                                    <form class="search-form">
                                        <input class="search-input" name="search" placeholder="Search" type="text">
                                        <button class="search-button" type="submit">
                                            <i class="bx bx-search"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                    </div> -->
                </div>
            </nav>
        </div>
    </div>
    <div class="side-nav-responsive">
        <div class="container">

            <div class="container">
                <div class="side-nav-inner">
                    <div class="side-nav justify-content-center align-items-center">
                        <div class="side-item">
                            <div class="option-item">
                                <div class="menu-icon d-in-line">
                                    <a href="#" class="burger-menu menu-icon-two">
                                        <i class='flaticon-menu'></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="side-item">
                            <div class="option-item">
                                <i class='search-btn bx bx-search'></i>
                                <i class='close-btn bx bx-x'></i>
                                <div class="search-overlay search-popup">
                                    <div class='search-box'>
                                        <form class="search-form">
                                            <input class="search-input" name="search" placeholder="Search"
                                                type="text">
                                            <button class="search-button" type="submit">
                                                <i class="bx bx-search"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('web_script'); ?>
    <script>
        (function($) {
            var defaults = {
                sm: 540,
                md: 720,
                lg: 960,
                xl: 1140,
                navbar_expand: 'lg'
            };
            $.fn.bootnavbar = function() {

                var screen_width = $(document).width();

                if (screen_width >= defaults.lg) {
                    $(this).find('.dropdown').hover(function() {
                        $(this).addClass('show');
                        $(this).find('.dropdown-menu').first().addClass('show').addClass('animated fadeIn')
                            .one('animationend oAnimationEnd mozAnimationEnd webkitAnimationEnd',
                                function() {
                                    $(this).removeClass('animated fadeIn');
                                });
                    }, function() {
                        $(this).removeClass('show');
                        $(this).find('.dropdown-menu').first().removeClass('show');
                    });
                }

                $('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
                    if (!$(this).next().hasClass('show')) {
                        $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
                    }
                    var $subMenu = $(this).next(".dropdown-menu");
                    $subMenu.toggleClass('show');

                    $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
                        $('.dropdown-submenu .show').removeClass("show");
                    });

                    return false;
                });
            };
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\xampp\htdocs\bdcongroup\resources\views/partials/web_header.blade.php ENDPATH**/ ?>