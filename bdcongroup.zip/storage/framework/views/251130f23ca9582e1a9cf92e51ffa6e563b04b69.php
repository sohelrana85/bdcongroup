
<?php $__env->startSection('title', 'Product Details'); ?>
<?php $__env->startSection('main_content'); ?>

    <div class="inner-banner inner-bg11">
        <div class="container">
            <div class="inner-title text-center">
                <h3>Product Details</h3>
                <ul>
                    <li>
                        <a href="<?php echo e(route('index')); ?>">Home</a>
                    </li>
                    <li>
                        <i class='bx bxs-chevron-right'></i>
                    </li>
                    <li>Product Details</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="product_detail pt-4 pb-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-5 col-12">
                    <div class="xzoom-container">
                        <img src="<?php echo e(asset($product->image)); ?>" class="xzoom w-100" xoriginal="<?php echo e(asset($product->image)); ?>" alt="">
                        <div class="xzoom-thumbs mt-2">
                            <a href="<?php echo e(asset($product->image)); ?>">
                                <img src="<?php echo e(asset($product->image)); ?>" class="xzoom-gallery" xpreview="<?php echo e(asset($product->image)); ?>" alt="">
                            </a>
                            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                            <a href="<?php echo e(asset($item->other_img)); ?>">
                                <img src="<?php echo e(asset($item->other_img)); ?>" class="xzoom-gallery" xpreview="<?php echo e(asset($item->other_img)); ?>" alt="">
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <div class="col-lg-7 col-md-7 col-12">
                    <div class="right_details">
                        <h3><?php echo e($product->name); ?></h3>
                        <div class="">
                            <h5 class="text-black">Price: ৳<?php echo e($product->price); ?></h5>
                        </div>
                        <div class="">
                            <p class=""><strong>Product Code:</strong> <?php echo e($product->product_code); ?></p>
                        </div>
                        <div class="">
                            <p class=""><strong>Category:</strong> <?php echo e($product->category->name); ?></p>
                        </div>

                        <div class="product_info py-3">
                            <?php echo Str::limit($product->description, 150); ?>

                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="product_detail pt-4 pb-4">
        <div class="container">
            <div class="row">
                <h5>Product Description</h5>
                <hr>
                <p><?php echo $product->description; ?></p>
            </div>
        </div>
    </div>

    <div class="project-area pt-2 pb-4">
        <div class="container">
            <div class="project-title-two">
                <div class="section-title">
                    <h2>Related Products</h2>
                </div>
            </div>
            <div class="tab project-tab text-center">
                
                <div class="tab_content pt-2">
                    <div class="tabs_item">
                        <div class="project-tab-item">
                            <div class="row">
                                <?php $__currentLoopData = $related_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                <div class="col-lg-3 col-md-6">
                                    <div class="project-card">
                                        <a href="<?php echo e(route('product.single', $item->slug)); ?>">
                                            <img src="<?php echo e(asset($item->image)); ?>" alt="Images">
                                        </a>
                                        <div class="project-content project-content-bg">
                                            <h3><a href="<?php echo e(route('product.single', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
                                            <div class="content">
                                                <h5>৳<?php echo e($item->price); ?></h5>
                                                <a href="<?php echo e(route('product.single', $item->slug)); ?>" class="project-more">
                                                    View Details<i class='flaticon-double-right-arrows-angles'></i>
                                                </a>
                                            </div>
                                            <div class="project-card-bottom"></div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('web_script'); ?>
    <script>
        $(function() {
            $(".xzoom, .xzoom-gallery").xzoom({
                zoomWith: 400,
                tint: "#333",
                Xoffset: 15
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\arrazzaq_corporation\resources\views/pages/product_single.blade.php ENDPATH**/ ?>