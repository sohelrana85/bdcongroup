
<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('main_content'); ?>

    <div class="inner-banner inner-bg11">
        <div class="container">
            <div class="inner-title text-center">
                <h3>Products</h3>
                <ul>
                    <li>
                        <a href="<?php echo e(route('index')); ?>">Home</a>
                    </li>
                    <li>
                        <i class='bx bxs-chevron-right'></i>
                    </li>
                    <li>Products</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="product-section">
        <div class="container">
            <div class="tab project-tab text-center">   
                <div class="tab_content pt-2">
                    <div class="tabs_item">
                        <div class="project-tab-item">
                            <div class="row">
                                <?php if($products->count() > 0): ?>  
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                    <div class="col-lg-3 col-md-6">
                                        <div class="project-card">
                                            <a href="<?php echo e(route('product.single', $item->slug)); ?>">
                                                <img src="<?php echo e(asset($item->image)); ?>" alt="Images">
                                            </a>
                                            <div class="project-content project-content-bg">
                                                <h3><a href="<?php echo e(route('product.single', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
                                                <div class="content">
                                                    <h5>৳<?php echo e($item->price); ?></h5>
                                                    <a href="<?php echo e(route('product.single', $item->slug)); ?>" class="project-more">
                                                        View Details<i class='flaticon-double-right-arrows-angles'></i>
                                                    </a>
                                                </div>
                                                <div class="project-card-bottom"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="col-12 text-center">
                                        <h5 class="text-danger py-5">Product Not Found!</h5>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="d-flex justify-content-center">
                                <?php echo e($products->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bdcongroup\resources\views/pages/products.blade.php ENDPATH**/ ?>